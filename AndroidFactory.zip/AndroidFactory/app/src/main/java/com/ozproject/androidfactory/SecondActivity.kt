package com.ozproject.androidfactory

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

//       val  textFromMainActivity = intent.getStringExtra("Title")
//        val textView  : TextView = findViewById(R.id.movieDes)
//        textView.text = textFromMainActivity
        val title = findViewById<TextView>(R.id.movieDes)
        title.text = intent.getStringExtra("Title")

    }
}
